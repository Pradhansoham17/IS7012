﻿namespace RecruitCatPradhasm.Models
{
    public class Industry
    {
        public int Id { get; set; }
        public string industryName { get; set; }
        public string industryType { get; set; }
        public List<Candidate> industryCandidates { get; set; }
        public List<Company> industryCompanies { get; set; }
    }
}
