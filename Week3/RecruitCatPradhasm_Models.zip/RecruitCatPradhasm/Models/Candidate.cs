﻿namespace RecruitCatPradhasm.Models
{
    public class Candidate
    {
        public int Id { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public decimal targetSalary { get; set; }
        public DateTime? startDate { get; set; }
        public string previousCompany { get; set; }
        public string preferredLocation { get; set; }
        public Company? candidateCompany { get; set; }
        public JobTitle candidateJobTitle { get; set; }
        public Industry candidateIndustry { get; set; }
        public int? candidateCompanyId { get; set; }
        public int candidateJobTitleId { get; set; }
        public int candidateIndustryId { get; set; }
    }
}
