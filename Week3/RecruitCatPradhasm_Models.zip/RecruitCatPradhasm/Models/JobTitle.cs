﻿namespace RecruitCatPradhasm.Models
{
    public class JobTitle
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public decimal minSalary { get; set; }
        public decimal maxSalary { get; set; }
        public string skills { get; set; }
        public bool? workRemoteRequired { get; set; }
        public List<Candidate> jobTitleCandidates { get; set; }
    }
}
