﻿namespace RecruitCatPradhasm.Models
{
    public class Company
    {
        public int Id { get; set; }
        public string companyName { get; set; }
        public string recruitingPosition { get; set; }
        public decimal minSalary { get; set; }
        public decimal maxSalary { get; set; }
        public DateTime? startDate { get; set; }
        public string location { get; set; }
        public bool isRelocationRequired { get; set; }
        public List<Candidate> companyCandidates { get; set; }
        public Industry companyIndustry { get; set; }
        public int companyIndustryId { get; set; }
    }
}
