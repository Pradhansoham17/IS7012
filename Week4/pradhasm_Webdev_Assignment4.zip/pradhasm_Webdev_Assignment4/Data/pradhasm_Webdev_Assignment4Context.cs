﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using pradhasm_Webdev_Assignment4.Models;

namespace pradhasm_Webdev_Assignment4.Data
{
    public class pradhasm_Webdev_Assignment4Context : DbContext
    {
        public pradhasm_Webdev_Assignment4Context (DbContextOptions<pradhasm_Webdev_Assignment4Context> options)
            : base(options)
        {
        }

        public DbSet<pradhasm_Webdev_Assignment4.Models.Candidate> Candidate { get; set; } = default!;

        public DbSet<pradhasm_Webdev_Assignment4.Models.Company> Company { get; set; }

        public DbSet<pradhasm_Webdev_Assignment4.Models.Industry> Industry { get; set; }

        public DbSet<pradhasm_Webdev_Assignment4.Models.JobTitle> JobTitle { get; set; }
    }
}
