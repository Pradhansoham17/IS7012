﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace pradhasm_Webdev_Assignment4.Migrations
{
    public partial class Industrys : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
