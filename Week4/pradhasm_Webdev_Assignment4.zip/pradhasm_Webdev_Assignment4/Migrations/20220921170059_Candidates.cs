﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace pradhasm_Webdev_Assignment4.Migrations
{
    public partial class Candidates : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Industry",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    industryName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    industryType = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Industry", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "JobTitle",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    minSalary = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    maxSalary = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    skills = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    workRemoteRequired = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JobTitle", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Company",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    companyName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    recruitingPosition = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    minSalary = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    maxSalary = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    startDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    location = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isRelocationRequired = table.Column<bool>(type: "bit", nullable: false),
                    companyIndustryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Company", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Company_Industry_companyIndustryId",
                        column: x => x.companyIndustryId,
                        principalTable: "Industry",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Candidate",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    firstname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    lastname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    targetSalary = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    startDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    previousCompany = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    preferredLocation = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    candidateCompanyId = table.Column<int>(type: "int", nullable: true),
                    candidateJobTitleId = table.Column<int>(type: "int", nullable: false),
                    candidateIndustryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Candidate", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Candidate_Company_candidateCompanyId",
                        column: x => x.candidateCompanyId,
                        principalTable: "Company",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Candidate_Industry_candidateIndustryId",
                        column: x => x.candidateIndustryId,
                        principalTable: "Industry",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Candidate_JobTitle_candidateJobTitleId",
                        column: x => x.candidateJobTitleId,
                        principalTable: "JobTitle",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Candidate_candidateCompanyId",
                table: "Candidate",
                column: "candidateCompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_Candidate_candidateIndustryId",
                table: "Candidate",
                column: "candidateIndustryId");

            migrationBuilder.CreateIndex(
                name: "IX_Candidate_candidateJobTitleId",
                table: "Candidate",
                column: "candidateJobTitleId");

            migrationBuilder.CreateIndex(
                name: "IX_Company_companyIndustryId",
                table: "Company",
                column: "companyIndustryId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Candidate");

            migrationBuilder.DropTable(
                name: "Company");

            migrationBuilder.DropTable(
                name: "JobTitle");

            migrationBuilder.DropTable(
                name: "Industry");
        }
    }
}
