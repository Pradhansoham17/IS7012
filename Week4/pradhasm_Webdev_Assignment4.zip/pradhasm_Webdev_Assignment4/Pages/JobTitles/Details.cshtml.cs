﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using pradhasm_Webdev_Assignment4.Data;
using pradhasm_Webdev_Assignment4.Models;

namespace pradhasm_Webdev_Assignment4.Pages.JobTitles
{
    public class DetailsModel : PageModel
    {
        private readonly pradhasm_Webdev_Assignment4.Data.pradhasm_Webdev_Assignment4Context _context;

        public DetailsModel(pradhasm_Webdev_Assignment4.Data.pradhasm_Webdev_Assignment4Context context)
        {
            _context = context;
        }

      public JobTitle JobTitle { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.JobTitle == null)
            {
                return NotFound();
            }

            var jobtitle = await _context.JobTitle.FirstOrDefaultAsync(m => m.Id == id);
            if (jobtitle == null)
            {
                return NotFound();
            }
            else 
            {
                JobTitle = jobtitle;
            }
            return Page();
        }
    }
}
