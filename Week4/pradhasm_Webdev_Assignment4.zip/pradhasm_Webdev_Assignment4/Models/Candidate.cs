﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

//using pradhasm_Webdev_Assignment4.Models;

namespace pradhasm_Webdev_Assignment4.Models
{
    public class Candidate
    {
        [DisplayName("Candidate ID")]
        public int Id { get; set; }

        [DisplayName("Candidates First Name")]
        [StringLength(50, MinimumLength = 2)]
        public string firstname { get; set; }

        
        [DisplayName("Candidates Last Name")]
        [StringLength(50, MinimumLength = 2)]
        public string lastname { get; set; } 
        

        [DisplayName("Candidates Target Salary")]
        [Range(0, 10000000)]
        public decimal targetSalary { get; set; }
        

        [DisplayName("Candidates Start Date")]
        [DataType(DataType.Date)]
        public DateTime? startDate { get; set; }

        [DisplayName("Candidates Previous Company")]
        [StringLength(50, MinimumLength = 5)]
        public string previousCompany { get; set; }

        [DisplayName("Candidates Preferred Location")]
        public string preferredLocation { get; set; }

        [DisplayName("Interested Company")]
        public Company? candidateCompany { get; set; }

        [DisplayName("Interested Job Title")]
        public JobTitle? candidateJobTitle { get; set; }

        [DisplayName("Interested Industry")]
        public Industry? candidateIndustry { get; set; }

        [DisplayName("Interested Company")]
        public int? candidateCompanyId { get; set; }

        [DisplayName("Interested Job Title")]
        public int? candidateJobTitleId { get; set; }

        [DisplayName("Interested Industry")]
        public int? candidateIndustryId { get; set; }
    }
}
