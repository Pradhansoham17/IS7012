﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

//using pradhasm_Webdev_Assignment4.Models;

namespace pradhasm_Webdev_Assignment4.Models
{
    public class Company
    {
        [DisplayName("Company ID ")]
        public int Id { get; set; }

        [DisplayName("Company Name ")]
        [StringLength(50, MinimumLength = 5)]
        public string companyName { get; set; }
        

        [DisplayName("Recruiting Position ")]
        [StringLength(50, MinimumLength = 5)]
        public string recruitingPosition { get; set; }

        [DisplayName("Minimum Salary ")]
        [Range(0, 10000000)]
        public decimal minSalary { get; set; }
        

        [DisplayName("Maximum Salary ")]
        [Range(0, 10000000)]
        public decimal maxSalary { get; set; }
        

        [DisplayName("Starting Date ")]
        [DataType(DataType.Date)]
        public DateTime? startDate { get; set; }

        [DisplayName("Location ")]
        [StringLength(50, MinimumLength = 5)]
        public string location { get; set; }

        [DisplayName("Is Relocation Required ? ")]
        public bool isRelocationRequired { get; set; }

        
        public List<Candidate>? companyCandidates { get; set; }

        [DisplayName("Associated Industry ")]
        public Industry? companyIndustry { get; set; }

        [DisplayName("Associated Industry ")]
        public int? companyIndustryId { get; set; }
    }
}
