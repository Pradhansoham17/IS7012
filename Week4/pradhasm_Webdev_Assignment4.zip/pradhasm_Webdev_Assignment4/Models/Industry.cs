﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace pradhasm_Webdev_Assignment4.Models
{
    public class Industry
    {
        [DisplayName("Industry ID ")]
        public int Id { get; set; }

        [DisplayName("Industry Name ")]
        [StringLength(50, MinimumLength = 5)]
        public string industryName { get; set; }

        [DisplayName("Industry Type ")]
        public string industryType { get; set; }

        
        public List<Candidate>? industryCandidates { get; set; }

        
        public List<Company>? industryCompanies { get; set; }
    }
}
