﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace pradhasm_Webdev_Assignment4.Models
{
    public class JobTitle
    {
        [DisplayName("Job Title ID ")]
        public int Id { get; set; }

        [DisplayName("Job Title ")]
        [StringLength(50, MinimumLength = 5)]
        public string Title { get; set; }

        [DisplayName("Minimum Salary ")]
        [Range(0, 10000000)]
        public decimal minSalary { get; set; }
        

        [DisplayName("Maximum Salary ")]
        [Range(0, 10000000)]
        public decimal maxSalary { get; set; }
        

        [DisplayName("Required Skills ")]
        public string skills { get; set; }

        [DisplayName("Is Remote Working Required ? ")]
        public bool? workRemoteRequired { get; set; }

     
        public List<Candidate>? jobTitleCandidates { get; set; }
    }
}
